package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;

import java.util.List;

public class BackLogic {

    /**
     * /back <номер> — телепорт к сохранённой точке смерти по номеру.
     */
    public static int back(CommandSourceStack source, int number) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());
        ModSavedData.Location loc = data.getDeath(player.getUUID(), number);

        if (loc == null) {
            LogicUtil.sendFailure(source, "Точка смерти #" + number + " не найдена.");
            return 0;
        }

        HomeLogic.teleportToLocation(player, loc);

        LogicUtil.sendSuccess(source, "Вы телепортированы к точке смерти #" + number + ".");
        return 1;
    }

    /**
     * /back list — список всех сохранённых смертей игрока с номерами и координатами.
     */
    public static int list(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());
        List<ModSavedData.Location> deaths = data.getDeaths(player.getUUID());

        if (deaths.isEmpty()) {
            LogicUtil.sendSuccess(source, "У вас пока нет зарегистрированных смертей.");
            return 1;
        }

        StringBuilder sb = new StringBuilder("Ваши смерти:");
        for (int i = 0; i < deaths.size(); i++) {
            ModSavedData.Location loc = deaths.get(i);
            sb.append("\n#").append(i + 1).append(": ")
                    .append((int) loc.x).append(", ")
                    .append((int) loc.y).append(", ")
                    .append((int) loc.z)
                    .append(" (").append(loc.dimension.location()).append(")");
        }

        LogicUtil.sendSuccess(source, sb.toString());
        return 1;
    }
}
