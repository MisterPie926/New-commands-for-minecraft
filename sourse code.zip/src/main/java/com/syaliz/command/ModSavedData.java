package com.syaliz.command;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.storage.DimensionDataStorage;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Единое хранилище данных мода: дома игроков, варпы и точки смерти.
 * Хранится через ванильный механизм SavedData (per-world), переживает
 * перезапуск сервера и /reload.
 */
public class ModSavedData extends SavedData {

    private static final String DATA_NAME = "newcommands_data";

    // playerUUID -> (homeName -> Location)
    private final Map<UUID, Map<String, Location>> homes = new LinkedHashMap<>();

    // warpName -> Location (глобальные, регистр имени не важен, храним как задано)
    private final Map<String, Location> warps = new LinkedHashMap<>();

    // playerUUID -> список точек смерти (по порядку, индекс+1 = номер для /back)
    private final Map<UUID, List<Location>> deaths = new LinkedHashMap<>();

    public static ModSavedData get(MinecraftServer server) {
        ServerLevel overworld = server.overworld();
        DimensionDataStorage storage = overworld.getDataStorage();
        return storage.computeIfAbsent(ModSavedData::load, ModSavedData::new, DATA_NAME);
    }

    // ---------- Homes ----------

    public Map<String, Location> getHomes(UUID player) {
        return homes.computeIfAbsent(player, k -> new LinkedHashMap<>());
    }

    public void setHome(UUID player, String name, Location loc) {
        getHomes(player).put(name.toLowerCase(), loc);
        setDirty();
    }

    public Location getHome(UUID player, String name) {
        return getHomes(player).get(name.toLowerCase());
    }

    public boolean removeHome(UUID player, String name) {
        boolean removed = getHomes(player).remove(name.toLowerCase()) != null;
        if (removed) {
            setDirty();
        }
        return removed;
    }

    /**
     * Возвращает следующее свободное имя дома по умолчанию: home, home1, home2, ...
     */
    public String nextDefaultHomeName(UUID player) {
        Map<String, Location> playerHomes = getHomes(player);
        if (!playerHomes.containsKey("home")) {
            return "home";
        }
        int i = 1;
        while (playerHomes.containsKey("home" + i)) {
            i++;
        }
        return "home" + i;
    }

    // ---------- Warps ----------

    public Map<String, Location> getWarps() {
        return warps;
    }

    public void setWarp(String name, Location loc) {
        warps.put(name.toLowerCase(), loc);
        setDirty();
    }

    public Location getWarp(String name) {
        return warps.get(name.toLowerCase());
    }

    public boolean removeWarp(String name) {
        boolean removed = warps.remove(name.toLowerCase()) != null;
        if (removed) {
            setDirty();
        }
        return removed;
    }

    // ---------- Deaths (для /back) ----------

    public List<Location> getDeaths(UUID player) {
        return deaths.computeIfAbsent(player, k -> new ArrayList<>());
    }

    public int addDeath(UUID player, Location loc) {
        List<Location> list = getDeaths(player);
        list.add(loc);
        setDirty();
        return list.size(); // номер этой смерти
    }

    public Location getDeath(UUID player, int number) {
        List<Location> list = getDeaths(player);
        if (number < 1 || number > list.size()) {
            return null;
        }
        return list.get(number - 1);
    }

    // ---------- NBT (de)serialization ----------

    @Override
    public CompoundTag save(CompoundTag tag) {
        // homes
        ListTag homesList = new ListTag();
        for (Map.Entry<UUID, Map<String, Location>> entry : homes.entrySet()) {
            for (Map.Entry<String, Location> home : entry.getValue().entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putUUID("player", entry.getKey());
                t.putString("name", home.getKey());
                home.getValue().save(t);
                homesList.add(t);
            }
        }
        tag.put("homes", homesList);

        // warps
        ListTag warpsList = new ListTag();
        for (Map.Entry<String, Location> entry : warps.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putString("name", entry.getKey());
            entry.getValue().save(t);
            warpsList.add(t);
        }
        tag.put("warps", warpsList);

        // deaths
        ListTag deathsList = new ListTag();
        for (Map.Entry<UUID, List<Location>> entry : deaths.entrySet()) {
            for (Location loc : entry.getValue()) {
                CompoundTag t = new CompoundTag();
                t.putUUID("player", entry.getKey());
                loc.save(t);
                deathsList.add(t);
            }
        }
        tag.put("deaths", deathsList);

        return tag;
    }

    public static ModSavedData load(CompoundTag tag) {
        ModSavedData data = new ModSavedData();

        ListTag homesList = tag.getList("homes", 10); // 10 = CompoundTag
        for (int i = 0; i < homesList.size(); i++) {
            CompoundTag t = homesList.getCompound(i);
            UUID player = t.getUUID("player");
            String name = t.getString("name");
            Location loc = Location.load(t);
            data.getHomes(player).put(name, loc);
        }

        ListTag warpsList = tag.getList("warps", 10);
        for (int i = 0; i < warpsList.size(); i++) {
            CompoundTag t = warpsList.getCompound(i);
            String name = t.getString("name");
            Location loc = Location.load(t);
            data.warps.put(name, loc);
        }

        ListTag deathsList = tag.getList("deaths", 10);
        for (int i = 0; i < deathsList.size(); i++) {
            CompoundTag t = deathsList.getCompound(i);
            UUID player = t.getUUID("player");
            Location loc = Location.load(t);
            data.getDeaths(player).add(loc);
        }

        return data;
    }

    /**
     * Простая структура координат + измерение.
     */
    public static class Location {
        public final ResourceKey<Level> dimension;
        public final double x, y, z;
        public final float yaw, pitch;

        public Location(ResourceKey<Level> dimension, double x, double y, double z, float yaw, float pitch) {
            this.dimension = dimension;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
            this.pitch = pitch;
        }

        public BlockPos toBlockPos() {
            return new BlockPos((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
        }

        public void save(CompoundTag t) {
            t.putString("dim", dimension.location().toString());
            t.putDouble("x", x);
            t.putDouble("y", y);
            t.putDouble("z", z);
            t.putFloat("yaw", yaw);
            t.putFloat("pitch", pitch);
        }

        public static Location load(CompoundTag t) {
            ResourceLocation dimLoc = ResourceLocation.tryParse(t.getString("dim"));
            ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, dimLoc);
            return new Location(
                    dimension,
                    t.getDouble("x"),
                    t.getDouble("y"),
                    t.getDouble("z"),
                    t.getFloat("yaw"),
                    t.getFloat("pitch")
            );
        }
    }
}
