package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;

public class UtilityLogic {

    private static final String REPAIR_COOLDOWN_TYPE = "repair";
    private static final String FEEDHEAL_COOLDOWN_TYPE = "feedheal";

    private static final long REPAIR_COOLDOWN_SECONDS = 60;
    private static final long FEEDHEAL_COOLDOWN_SECONDS = 30;

    // ---------- /repair ----------

    /**
     * /repair — чинит предмет в руке. Кулдаун 60с для обычных игроков,
     * без задержки для прав выше игрока (TRUSTED и выше).
     */
    public static int repair(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        boolean bypassCooldown = source.hasPermission(Permissions.TRUSTED);

        if (!bypassCooldown) {
            long remaining = CooldownManager.getRemainingSeconds(REPAIR_COOLDOWN_TYPE, player.getUUID(), REPAIR_COOLDOWN_SECONDS);
            if (remaining > 0) {
                LogicUtil.sendFailure(source, "Подождите ещё " + remaining + " сек. перед повторным /repair.");
                return 0;
            }
        }

        ItemStack held = player.getMainHandItem();
        if (held.isEmpty() || !held.isDamageableItem()) {
            LogicUtil.sendFailure(source, "В руке нет предмета, который можно починить.");
            return 0;
        }

        held.setDamageValue(0);

        if (!bypassCooldown) {
            CooldownManager.setUsed(REPAIR_COOLDOWN_TYPE, player.getUUID());
        }

        LogicUtil.sendSuccess(source, "Предмет в руке отремонтирован.");
        return 1;
    }

    /**
     * /repair all — чинит все предметы в инвентаре (включая броню). Доступно
     * только с правами TRUSTED и выше, без кулдауна.
     */
    public static int repairAll(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        int repaired = 0;
        for (ItemStack stack : player.getInventory().items) {
            if (!stack.isEmpty() && stack.isDamageableItem() && stack.getDamageValue() > 0) {
                stack.setDamageValue(0);
                repaired++;
            }
        }
        for (ItemStack stack : player.getInventory().armor) {
            if (!stack.isEmpty() && stack.isDamageableItem() && stack.getDamageValue() > 0) {
                stack.setDamageValue(0);
                repaired++;
            }
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (!stack.isEmpty() && stack.isDamageableItem() && stack.getDamageValue() > 0) {
                stack.setDamageValue(0);
                repaired++;
            }
        }

        LogicUtil.sendSuccess(source, "Отремонтировано предметов: " + repaired + ".");
        return 1;
    }

    // ---------- /feed ----------

    public static int feed(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        boolean bypassCooldown = source.hasPermission(Permissions.OP);

        if (!bypassCooldown) {
            long remaining = CooldownManager.getRemainingSeconds(FEEDHEAL_COOLDOWN_TYPE, player.getUUID(), FEEDHEAL_COOLDOWN_SECONDS);
            if (remaining > 0) {
                LogicUtil.sendFailure(source, "Подождите ещё " + remaining + " сек. перед повторным /feed.");
                return 0;
            }
        }

        player.getFoodData().setFoodLevel(20);
        player.getFoodData().setSaturation(20f);

        if (!bypassCooldown) {
            CooldownManager.setUsed(FEEDHEAL_COOLDOWN_TYPE, player.getUUID());
        }

        LogicUtil.sendSuccess(source, "Голод восполнен.");
        return 1;
    }

    // ---------- /heal ----------

    public static int heal(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        boolean bypassCooldown = source.hasPermission(Permissions.OP);

        if (!bypassCooldown) {
            long remaining = CooldownManager.getRemainingSeconds(FEEDHEAL_COOLDOWN_TYPE, player.getUUID(), FEEDHEAL_COOLDOWN_SECONDS);
            if (remaining > 0) {
                LogicUtil.sendFailure(source, "Подождите ещё " + remaining + " сек. перед повторным /heal.");
                return 0;
            }
        }

        player.setHealth(player.getMaxHealth());
        player.getFoodData().setFoodLevel(20);
        player.getFoodData().setSaturation(20f);

        if (!bypassCooldown) {
            CooldownManager.setUsed(FEEDHEAL_COOLDOWN_TYPE, player.getUUID());
        }

        LogicUtil.sendSuccess(source, "Здоровье восстановлено.");
        return 1;
    }

    // ---------- /trash ----------

    /**
     * Открывает игроку обычный 27-слотовый (9x3) сундук-мусорку.
     * Всё, что находится в нём при закрытии, уничтожается — контейнер
     * не сохраняется никуда и просто перестаёт существовать.
     */
    public static int trash(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        SimpleContainer trashContainer = new SimpleContainer(27);

        player.openMenu(new SimpleMenuProvider(
                (id, inv, p) -> ChestMenu.threeRows(id, inv, trashContainer),
                Component.literal("Мусорка")
        ));

        return 1;
    }
}
