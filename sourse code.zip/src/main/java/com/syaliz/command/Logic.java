package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.GameType;

/**
 * Логика базовых команд (перенесено из исходного мода, багфикс дублирования
 * сообщений: теперь только одно сообщение цели + короткое подтверждение
 * отправителю, если он выполнял команду не над собой; цвет — белый).
 */
public class Logic {

    // ---------- /gm ----------

    public static int setGameMode(CommandSourceStack source, ServerPlayer target, int mode) {
        GameType gameType = switch (mode) {
            case 0 -> GameType.SURVIVAL;
            case 1 -> GameType.CREATIVE;
            case 2 -> GameType.ADVENTURE;
            case 3 -> GameType.SPECTATOR;
            default -> GameType.SURVIVAL;
        };

        target.setGameMode(gameType);
        String modeName = gameType.getShortDisplayName().getString();

        LogicUtil.sendInfo(source, target,
                "Ваш режим игры изменён на: " + modeName,
                "Режим игры игрока " + target.getName().getString() + " изменён на: " + modeName);

        return 1;
    }

    // ---------- /fly ----------

    public static int toggleFly(CommandSourceStack source, ServerPlayer target) {
        boolean newState = !target.getAbilities().mayfly;

        target.getAbilities().mayfly = newState;
        if (!newState) {
            target.getAbilities().flying = false;
        }
        target.onUpdateAbilities();

        String status = newState ? "включён" : "выключен";

        LogicUtil.sendInfo(source, target,
                "Полёт " + status,
                "Полёт игрока " + target.getName().getString() + " " + status);

        return 1;
    }

    // ---------- /god ----------

    public static int toggleGod(CommandSourceStack source, ServerPlayer target) {
        boolean newState = !target.getAbilities().invulnerable;

        target.getAbilities().invulnerable = newState;
        target.onUpdateAbilities();

        String status = newState ? "включён" : "выключен";

        LogicUtil.sendInfo(source, target,
                "Режим бога " + status,
                "Режим бога игрока " + target.getName().getString() + " " + status);

        return 1;
    }

    // ---------- /speed ----------

    public static int setSpeed(CommandSourceStack source, ServerPlayer target, int value) {
        double walkSpeed = 0.1d * value / 2d;

        AttributeInstance attribute = target.getAttribute(Attributes.MOVEMENT_SPEED);
        if (attribute != null) {
            attribute.setBaseValue(walkSpeed);
        }

        LogicUtil.sendInfo(source, target,
                "Скорость ходьбы установлена на " + value,
                "Скорость ходьбы игрока " + target.getName().getString() + " установлена на " + value);

        return 1;
    }

    // ---------- /speedfly ----------

    public static int setFlySpeed(CommandSourceStack source, ServerPlayer target, int value) {
        double flySpeed = 0.05d * value / 2d;

        AttributeInstance attribute = target.getAttribute(Attributes.FLYING_SPEED);
        if (attribute != null) {
            attribute.setBaseValue(flySpeed);
        }

        LogicUtil.sendInfo(source, target,
                "Скорость полёта установлена на " + value,
                "Скорость полёта игрока " + target.getName().getString() + " установлена на " + value);

        return 1;
    }

    // ---------- /setspawn ----------

    public static int setSpawn(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ServerLevel level = source.getLevel();
        BlockPos pos = player.blockPosition();
        float yaw = player.getYRot();

        level.setDefaultSpawnPos(pos, yaw);

        LogicUtil.sendSuccess(source, "Точка спавна мира установлена на "
                + pos.getX() + ", " + pos.getY() + ", " + pos.getZ());

        return 1;
    }

    // ---------- /spawn ----------

    public static int teleportToSpawn(CommandSourceStack source, ServerPlayer target) {
        ServerLevel overworld = target.getServer().overworld();
        BlockPos spawnPos = overworld.getSharedSpawnPos();
        float spawnAngle = overworld.getSharedSpawnAngle();

        target.teleportTo(overworld,
                spawnPos.getX() + 0.5,
                spawnPos.getY(),
                spawnPos.getZ() + 0.5,
                spawnAngle,
                0f);

        LogicUtil.sendInfo(source, target,
                "Вы телепортированы на спавн",
                "Игрок " + target.getName().getString() + " телепортирован на спавн");

        return 1;
    }
}
