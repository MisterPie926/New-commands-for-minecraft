package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

public class HomeLogic {

    public static final String DEFAULT_NAME = "home";

    /**
     * /sethome [name] — если имя не указано, ставим "home"; если уже занято —
     * подбираем следующее свободное: home1, home2, ...
     * Если имя указано явно и уже занято — перезаписываем его (это явное намерение игрока).
     */
    public static int setHome(CommandSourceStack source, String requestedName) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());

        String name;
        if (requestedName == null || requestedName.isBlank()) {
            name = data.nextDefaultHomeName(player.getUUID());
        } else {
            name = requestedName;
        }

        ModSavedData.Location loc = new ModSavedData.Location(
                player.level().dimension(),
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot()
        );

        data.setHome(player.getUUID(), name, loc);

        LogicUtil.sendSuccess(source, "Дом \"" + name + "\" сохранён.");
        return 1;
    }

    /**
     * /home [name] — по умолчанию "home".
     */
    public static int home(CommandSourceStack source, String requestedName) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        String name = (requestedName == null || requestedName.isBlank()) ? DEFAULT_NAME : requestedName;

        ModSavedData data = ModSavedData.get(player.getServer());
        ModSavedData.Location loc = data.getHome(player.getUUID(), name);

        if (loc == null) {
            LogicUtil.sendFailure(source, "Дом \"" + name + "\" не найден.");
            return 0;
        }

        teleportToLocation(player, loc);

        LogicUtil.sendSuccess(source, "Вы телепортированы домой (\"" + name + "\").");
        return 1;
    }

    /**
     * /delhome name — имя обязательно.
     */
    public static int delHome(CommandSourceStack source, String name) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());
        boolean removed = data.removeHome(player.getUUID(), name);

        if (!removed) {
            LogicUtil.sendFailure(source, "Дом \"" + name + "\" не найден.");
            return 0;
        }

        LogicUtil.sendSuccess(source, "Дом \"" + name + "\" удалён.");
        return 1;
    }

    /**
     * /homes — список домов (вспомогательная команда, полезна раз имён может быть много).
     */
    public static int listHomes(CommandSourceStack source) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());
        Map<String, ModSavedData.Location> homes = data.getHomes(player.getUUID());

        if (homes.isEmpty()) {
            LogicUtil.sendSuccess(source, "У вас нет сохранённых домов.");
            return 1;
        }

        LogicUtil.sendSuccess(source, "Ваши дома: " + String.join(", ", homes.keySet()));
        return 1;
    }

    static void teleportToLocation(ServerPlayer player, ModSavedData.Location loc) {
        ServerLevel level = player.getServer().getLevel(loc.dimension);
        if (level == null) {
            level = player.serverLevel();
        }
        player.teleportTo(level, loc.x, loc.y, loc.z, loc.yaw, loc.pitch);
    }
}
