package com.syaliz.command;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Простой in-memory менеджер кулдаунов по (тип команды, UUID игрока).
 * Не сохраняется между перезапусками сервера — это ожидаемо для кулдаунов.
 */
public class CooldownManager {

    private static final Map<String, Map<UUID, Long>> COOLDOWNS = new HashMap<>();

    /**
     * Проверяет, готова ли команда к использованию.
     * @return оставшееся время в секундах (0 если кулдауна нет / готово)
     */
    public static long getRemainingSeconds(String type, UUID player, long cooldownSeconds) {
        Map<UUID, Long> map = COOLDOWNS.computeIfAbsent(type, k -> new HashMap<>());
        Long last = map.get(player);
        if (last == null) {
            return 0;
        }
        long elapsedMs = System.currentTimeMillis() - last;
        long remainingMs = (cooldownSeconds * 1000L) - elapsedMs;
        if (remainingMs <= 0) {
            return 0;
        }
        return (remainingMs + 999) / 1000; // округление вверх
    }

    public static void setUsed(String type, UUID player) {
        COOLDOWNS.computeIfAbsent(type, k -> new HashMap<>()).put(player, System.currentTimeMillis());
    }
}
