package com.syaliz.command;

import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Общие утилиты для команд: единое сообщение (без дублирования), белым цветом.
 *
 * Раньше (в старой версии) каждая команда слала ДВА сообщения:
 * одно напрямую игроку, второе — через source.sendSuccess (отправителю).
 * Если игрок сам себе выполнял команду, он получал оба — то есть видел
 * одно и то же дважды. Теперь отправляется ровно одно сообщение получателю
 * действия, плюс (только если это не он сам) короткое подтверждение отправителю.
 */
public final class LogicUtil {

    private LogicUtil() {
    }

    /**
     * Отправляет игроку-цели одно сообщение белым цветом.
     * Если источник команды — не сам целевой игрок (то есть кто-то применил
     * команду к другому игроку), отправитель получает отдельное короткое
     * подтверждающее сообщение. Дублирования одного и того же текста нет.
     */
    public static void sendInfo(CommandSourceStack source, ServerPlayer target, String targetMessage, String senderConfirm) {
        target.sendSystemMessage(Component.literal(targetMessage).withStyle(ChatFormatting.WHITE));

        if (source.getEntity() != target) {
            source.sendSuccess(() -> Component.literal(senderConfirm).withStyle(ChatFormatting.WHITE), true);
        }
    }

    /**
     * Вариант без учёта источника (например, для событийных сообщений вне команд).
     */
    public static void sendInfo(ServerPlayer target, String message) {
        target.sendSystemMessage(Component.literal(message).withStyle(ChatFormatting.WHITE));
    }

    /**
     * Отправляет отправителю команды одно сообщение белым цветом (когда нет
     * отдельной "цели", например /setspawn, /repair, /trash).
     */
    public static void sendSuccess(CommandSourceStack source, String message) {
        source.sendSuccess(() -> Component.literal(message).withStyle(ChatFormatting.WHITE), true);
    }

    public static void sendFailure(CommandSourceStack source, String message) {
        source.sendFailure(Component.literal(message).withStyle(ChatFormatting.WHITE));
    }
}
