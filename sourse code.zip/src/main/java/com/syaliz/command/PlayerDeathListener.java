package com.syaliz.command;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Слушает смерти игроков и записывает координаты смерти в ModSavedData,
 * чтобы команда /back могла к ним телепортировать.
 */
public class PlayerDeathListener {

    @SubscribeEvent
    public void onPlayerDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }

        ModSavedData data = ModSavedData.get(player.getServer());

        ModSavedData.Location loc = new ModSavedData.Location(
                player.level().dimension(),
                player.getX(),
                player.getY(),
                player.getZ(),
                player.getYRot(),
                player.getXRot()
        );

        int number = data.addDeath(player.getUUID(), loc);
        LogicUtil.sendInfo(player, "Точка смерти #" + number + " сохранена. Используй /back " + number);
    }
}
