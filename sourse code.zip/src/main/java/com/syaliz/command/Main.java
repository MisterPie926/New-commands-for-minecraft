package com.syaliz.command;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Главный класс мода NewCommands.
 * Регистрирует мод в Forge и подписывается на событие регистрации команд.
 */
@Mod(Main.MOD_ID)
@EventBusSubscriber(modid = Main.MOD_ID, bus = EventBusSubscriber.Bus.FORGE)
public class Main {

    public static final String MOD_ID = "newcommands";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public Main() {
        LOGGER.info("NewCommands mod loaded (mod_id={})", MOD_ID);

        // Подписываем слушатель смертей игроков (для /back)
        MinecraftForge.EVENT_BUS.register(new PlayerDeathListener());
    }

    /**
     * Вызывается сервером при регистрации всех команд.
     * Делегирует регистрацию классу Commands.
     */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        Commands.register(event.getDispatcher());
        LOGGER.info("NewCommands: commands registered");
    }
}
