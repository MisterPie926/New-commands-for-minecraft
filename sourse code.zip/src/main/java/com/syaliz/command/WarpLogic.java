package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;

public class WarpLogic {

    /**
     * /warp name — если имя не указано, просим указать.
     */
    public static int warp(CommandSourceStack source, String name) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        if (name == null || name.isBlank()) {
            LogicUtil.sendFailure(source, "Укажите название варпа: /warp <название>");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());
        ModSavedData.Location loc = data.getWarp(name);

        if (loc == null) {
            LogicUtil.sendFailure(source, "Варп \"" + name + "\" не найден.");
            return 0;
        }

        HomeLogic.teleportToLocation(player, loc);

        LogicUtil.sendSuccess(source, "Вы телепортированы на варп \"" + name + "\".");
        return 1;
    }

    /**
     * /setwarp name — доступно только для среднего уровня прав и выше.
     */
    public static int setWarp(CommandSourceStack source, String name) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        if (name == null || name.isBlank()) {
            LogicUtil.sendFailure(source, "Укажите название варпа: /setwarp <название>");
            return 0;
        }

        ModSavedData data = ModSavedData.get(player.getServer());

        ModSavedData.Location loc = new ModSavedData.Location(
                player.level().dimension(),
                player.getX(), player.getY(), player.getZ(),
                player.getYRot(), player.getXRot()
        );

        data.setWarp(name, loc);

        LogicUtil.sendSuccess(source, "Варп \"" + name + "\" сохранён.");
        return 1;
    }

    public static int delWarp(CommandSourceStack source, String name) {
        ModSavedData data = ModSavedData.get(source.getServer());
        boolean removed = data.removeWarp(name);

        if (!removed) {
            LogicUtil.sendFailure(source, "Варп \"" + name + "\" не найден.");
            return 0;
        }

        LogicUtil.sendSuccess(source, "Варп \"" + name + "\" удалён.");
        return 1;
    }

    public static int listWarps(CommandSourceStack source) {
        ModSavedData data = ModSavedData.get(source.getServer());
        Map<String, ModSavedData.Location> warps = data.getWarps();

        if (warps.isEmpty()) {
            LogicUtil.sendSuccess(source, "Нет сохранённых варпов.");
            return 1;
        }

        LogicUtil.sendSuccess(source, "Доступные варпы: " + String.join(", ", warps.keySet()));
        return 1;
    }
}
