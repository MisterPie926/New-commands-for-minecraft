package com.syaliz.command;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.storage.ServerLevelData;

public class AdminLogic {

    // ---------- /s <nickname> — телепортирует игрока К СЕБЕ ----------

    public static int summonPlayer(CommandSourceStack source, ServerPlayer target) {
        ServerPlayer self;
        try {
            self = source.getPlayerOrException();
        } catch (Exception e) {
            LogicUtil.sendFailure(source, "Эту команду может выполнять только игрок.");
            return 0;
        }

        if (self == target) {
            LogicUtil.sendFailure(source, "Нельзя телепортировать себя к себе.");
            return 0;
        }

        target.teleportTo(self.serverLevel(), self.getX(), self.getY(), self.getZ(), self.getYRot(), self.getXRot());

        LogicUtil.sendInfo(source, target,
                "Вас телепортировали к игроку " + self.getName().getString(),
                "Игрок " + target.getName().getString() + " телепортирован к вам");

        return 1;
    }

    // ---------- /day /night /sun /rain /timestop ----------

    private static final long DAY_TIME = 1000L;
    private static final long NIGHT_TIME = 13000L;

    public static int setDay(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        level.setDayTime(DAY_TIME);
        LogicUtil.sendSuccess(source, "Установлен день.");
        return 1;
    }

    public static int setNight(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        level.setDayTime(NIGHT_TIME);
        LogicUtil.sendSuccess(source, "Установлена ночь.");
        return 1;
    }

    public static int setSun(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        level.setWeatherParameters(0, 0, false, false);
        LogicUtil.sendSuccess(source, "Установлена ясная погода.");
        return 1;
    }

    public static int setRain(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        level.setWeatherParameters(0, 6000, true, false);
        LogicUtil.sendSuccess(source, "Установлен дождь.");
        return 1;
    }

    /**
     * /timestop — переключает doDaylightCycle (стоп/пуск смены дня и ночи).
     */
    public static int toggleTimeStop(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        GameRules.BooleanValue rule = level.getGameRules().getRule(GameRules.RULE_DAYLIGHT);

        boolean current = rule.get();
        rule.set(!current, level.getServer());

        String status = !current ? "остановлено" : "запущено";
        LogicUtil.sendSuccess(source, "Течение времени " + status + ".");
        return 1;
    }
}
