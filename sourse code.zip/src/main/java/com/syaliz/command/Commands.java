package com.syaliz.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;

import static net.minecraft.commands.Commands.argument;
import static net.minecraft.commands.Commands.literal;

/**
 * Регистрация всех команд мода NewCommands.
 * Вся фактическая логика вынесена в классы Logic / HomeLogic / WarpLogic /
 * BackLogic / UtilityLogic / AdminLogic.
 *
 * Уровни прав (см. Permissions.java):
 *   PLAYER (0)  — доступно всем
 *   TRUSTED (1) — средний уровень (fly, god, gm, teleport-to-me, setwarp/setspawn, погода/время)
 *   OP (2)      — полноценные операторы (используется как верхняя граница, где нужно)
 */
public class Commands {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {

        registerPlayerCommands(dispatcher);
        registerTrustedCommands(dispatcher);
    }

    // =========================================================================================
    //  Команды, доступные ВСЕМ игрокам (Permissions.PLAYER)
    // =========================================================================================

    private static void registerPlayerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {

        // ---------- /sethome [name] ----------
        dispatcher.register(
                literal("sethome")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> HomeLogic.setHome(ctx.getSource(), null))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> HomeLogic.setHome(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /home [name] ----------
        dispatcher.register(
                literal("home")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> HomeLogic.home(ctx.getSource(), null))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> HomeLogic.home(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /homes (список домов игрока) ----------
        dispatcher.register(
                literal("homes")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> HomeLogic.listHomes(ctx.getSource()))
        );

        // ---------- /delhome name ----------
        dispatcher.register(
                literal("delhome")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> HomeLogic.delHome(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /warp name ----------
        dispatcher.register(
                literal("warp")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> WarpLogic.warp(ctx.getSource(), null))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> WarpLogic.warp(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /warps (список варпов) ----------
        dispatcher.register(
                literal("warps")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> WarpLogic.listWarps(ctx.getSource()))
        );

        // ---------- /spawn (логика не меняется, уровень прав как раньше был — оставляем PLAYER,
        //             это базовая команда для всех) ----------
        dispatcher.register(
                literal("spawn")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> Logic.teleportToSpawn(ctx.getSource(), getSelfOrSender(ctx.getSource())))
                        .then(argument("player", EntityArgument.player())
                                .requires(src -> src.hasPermission(Permissions.TRUSTED)) // телепорт ДРУГОГО игрока — уже не базовое право
                                .executes(ctx -> Logic.teleportToSpawn(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"))))
        );

        // ---------- /back <number> | /back list ----------
        dispatcher.register(
                literal("back")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .then(literal("list")
                                .executes(ctx -> BackLogic.list(ctx.getSource())))
                        .then(argument("number", IntegerArgumentType.integer(1))
                                .executes(ctx -> BackLogic.back(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "number"))))
        );

        // ---------- /repair  and /repair all ----------
        dispatcher.register(
                literal("repair")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> UtilityLogic.repair(ctx.getSource()))
                        .then(literal("all")
                                .requires(src -> src.hasPermission(Permissions.TRUSTED))
                                .executes(ctx -> UtilityLogic.repairAll(ctx.getSource())))
        );

        // ---------- /trash ----------
        dispatcher.register(
                literal("trash")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> UtilityLogic.trash(ctx.getSource()))
        );

        // ---------- /feed ----------
        dispatcher.register(
                literal("feed")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> UtilityLogic.feed(ctx.getSource()))
        );

        // ---------- /heal ----------
        dispatcher.register(
                literal("heal")
                        .requires(src -> src.hasPermission(Permissions.PLAYER))
                        .executes(ctx -> UtilityLogic.heal(ctx.getSource()))
        );
    }

    // =========================================================================================
    //  Команды, доступные с минимальным "повышенным" уровнем прав (Permissions.TRUSTED)
    // =========================================================================================

    private static void registerTrustedCommands(CommandDispatcher<CommandSourceStack> dispatcher) {

        // ---------- /gm <0|1|2|3> [player] ----------
        dispatcher.register(
                literal("gm")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(literal("0")
                                .executes(ctx -> Logic.setGameMode(ctx.getSource(), getSelfOrSender(ctx.getSource()), 0))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setGameMode(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 0))))
                        .then(literal("1")
                                .executes(ctx -> Logic.setGameMode(ctx.getSource(), getSelfOrSender(ctx.getSource()), 1))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setGameMode(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 1))))
                        .then(literal("2")
                                .executes(ctx -> Logic.setGameMode(ctx.getSource(), getSelfOrSender(ctx.getSource()), 2))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setGameMode(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 2))))
                        .then(literal("3")
                                .executes(ctx -> Logic.setGameMode(ctx.getSource(), getSelfOrSender(ctx.getSource()), 3))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setGameMode(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), 3))))
        );

        // ---------- /fly [player] ----------
        dispatcher.register(
                literal("fly")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> Logic.toggleFly(ctx.getSource(), getSelfOrSender(ctx.getSource())))
                        .then(argument("player", EntityArgument.player())
                                .executes(ctx -> Logic.toggleFly(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"))))
        );

        // ---------- /god [player] ----------
        dispatcher.register(
                literal("god")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> Logic.toggleGod(ctx.getSource(), getSelfOrSender(ctx.getSource())))
                        .then(argument("player", EntityArgument.player())
                                .executes(ctx -> Logic.toggleGod(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"))))
        );

        // ---------- /speed <1-10> [player] ----------
        dispatcher.register(
                literal("speed")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(argument("value", IntegerArgumentType.integer(1, 10))
                                .executes(ctx -> Logic.setSpeed(ctx.getSource(), getSelfOrSender(ctx.getSource()),
                                        IntegerArgumentType.getInteger(ctx, "value")))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setSpeed(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"),
                                                IntegerArgumentType.getInteger(ctx, "value")))))
        );

        // ---------- /speedfly <1-10> [player] ----------
        dispatcher.register(
                literal("speedfly")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(argument("value", IntegerArgumentType.integer(1, 10))
                                .executes(ctx -> Logic.setFlySpeed(ctx.getSource(), getSelfOrSender(ctx.getSource()),
                                        IntegerArgumentType.getInteger(ctx, "value")))
                                .then(argument("player", EntityArgument.player())
                                        .executes(ctx -> Logic.setFlySpeed(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"),
                                                IntegerArgumentType.getInteger(ctx, "value")))))
        );

        // ---------- /setspawn ----------
        dispatcher.register(
                literal("setspawn")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> Logic.setSpawn(ctx.getSource()))
        );

        // ---------- /setwarp name ----------
        dispatcher.register(
                literal("setwarp")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> WarpLogic.setWarp(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /delwarp name ----------
        dispatcher.register(
                literal("delwarp")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(argument("name", StringArgumentType.word())
                                .executes(ctx -> WarpLogic.delWarp(ctx.getSource(), StringArgumentType.getString(ctx, "name"))))
        );

        // ---------- /s nickname — телепортирует указанного игрока к себе ----------
        dispatcher.register(
                literal("s")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .then(argument("player", EntityArgument.player())
                                .executes(ctx -> AdminLogic.summonPlayer(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"))))
        );

        // ---------- /day /night /sun /rain /timestop ----------
        dispatcher.register(
                literal("day")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> AdminLogic.setDay(ctx.getSource()))
        );

        dispatcher.register(
                literal("night")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> AdminLogic.setNight(ctx.getSource()))
        );

        dispatcher.register(
                literal("sun")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> AdminLogic.setSun(ctx.getSource()))
        );

        dispatcher.register(
                literal("rain")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> AdminLogic.setRain(ctx.getSource()))
        );

        dispatcher.register(
                literal("timestop")
                        .requires(src -> src.hasPermission(Permissions.TRUSTED))
                        .executes(ctx -> AdminLogic.toggleTimeStop(ctx.getSource()))
        );
    }

    /**
     * Возвращает игрока-отправителя команды, если цель не указана явно.
     * Бросит понятную ошибку, если команду выполняет не игрок (например, консоль).
     */
    private static ServerPlayer getSelfOrSender(CommandSourceStack source) {
        try {
            return source.getPlayerOrException();
        } catch (Exception e) {
            throw new RuntimeException("Эту команду без указания игрока может выполнять только игрок.");
        }
    }
}
