package com.syaliz.command;

/**
 * Уровни доступа к командам (используются как vanilla permission level).
 *
 * PLAYER (0) — доступно всем игрокам без исключения.
 * TRUSTED (1) — "доверенные" / средний уровень (выше игрока, ниже опа).
 * OP (2)      — полноценные операторы сервера.
 */
public final class Permissions {

    public static final int PLAYER = 0;
    public static final int TRUSTED = 1;
    public static final int OP = 2;

    private Permissions() {
    }
}
